const Header = () => {
	return (
		<header>
			<h1>Everything is Awesome Blog</h1>
		</header>
	);
};

export default Header;
