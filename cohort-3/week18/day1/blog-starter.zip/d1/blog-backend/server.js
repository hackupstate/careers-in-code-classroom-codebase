const express = require("express");
const server = express();
const cors = require("cors");
server.use(cors());
const bodyParser = require("body-parser");
server.use(bodyParser.json());
const bcrypt = require("bcrypt");

const { db, User } = require("./db/db.js");

server.get("/", (req, res) => {
  res.send({ hello: "world" });
});

server.post("/login", async (req, res) => {
  const user = await User.findOne({ where: { username: req.body.username } });
  if (!user) {
    res.send({ error: "username not found" });
  } else {
    const matchingPassword = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (matchingPassword) {
      res.send({ success: true, message: "open sesame" });
    } else {
      res.send({ error: "no go. passwords no match." });
    }
  }
});

server.listen(3001, () => {
  console.log("Server running.");
});

const createFirstUser = async () => {
  const users = await User.findAll();
  if (users.length === 0) {
    User.create({
      username: "max",
      password: bcrypt.hashSync("supersecret", 10),
    });
  }
};

createFirstUser();
