import "./Pretty.scss";

const Home = () => {
	return (
		<div id="home">
			<h1>Home Page</h1>
			<h2>Example</h2>
			<p>Max is boring</p>
		</div>
	);
};

export default Home;
