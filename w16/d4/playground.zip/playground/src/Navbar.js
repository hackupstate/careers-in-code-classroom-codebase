import "./Navbar.scss";
const Navbar = () => {
	return (
		<div id="nav">
			<a href="google.com">Google</a>
			<a href="apple.com">Apple</a>
		</div>
	);
};

export default Navbar;
